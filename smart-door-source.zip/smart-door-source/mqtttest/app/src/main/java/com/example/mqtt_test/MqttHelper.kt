package com.example.mqtt_test
import android.content.Context
import android.util.Log
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.MqttClient


class MqttHelper(
    context: Context,
    private val topic: String,
    callback: MqttCallbackExtended,
) {
    private val mqttAndroidClient: MqttAndroidClient

    init {
        val clientId = MqttClient.generateClientId()
        mqttAndroidClient = MqttAndroidClient(context, serverUri, clientId)
        mqttAndroidClient.setCallback(callback)
        connect()
    }

    private fun connect() {
        val mqttConnectOptions = MqttConnectOptions()
        mqttConnectOptions.isAutomaticReconnect = true
        mqttConnectOptions.mqttVersion = MqttConnectOptions.MQTT_VERSION_3_1
        mqttConnectOptions.isCleanSession = false
//        mqttConnectOptions.userName = username
//        mqttConnectOptions.password = password.toCharArray()

        try {
            mqttAndroidClient.connect(
                mqttConnectOptions,
                "device-$topic",
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken) {

                        val disconnectedBufferOptions = DisconnectedBufferOptions()
                        disconnectedBufferOptions.isBufferEnabled = true
                        disconnectedBufferOptions.bufferSize = 100
                        disconnectedBufferOptions.isPersistBuffer = false
                        disconnectedBufferOptions.isDeleteOldestMessages = false
                        mqttAndroidClient.setBufferOpts(disconnectedBufferOptions)

                        Log.d(
                            "MainTrackingMqtt",
                            "Connected to ${asyncActionToken.client.serverURI}"
                        )

                        subscribeToTopic()
                    }

                    override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                        Log.d(
                            "MainTrackingMqtt",
                            "Failed to connect to: $serverUri ${exception.stackTrace}"
                        )
                        exception.printStackTrace()
                        println("Connection Failure!")
                        println("throwable: $exception")
                    }
                })

        } catch (ex: MqttException) {
            ex.printStackTrace()
        }
    }


    fun subscribeToTopics(topics: Array<String>, qos: IntArray) {
        try {
            mqttAndroidClient.subscribe(topics, qos, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken) {
                    Log.w("MainTrackingMqtt", "Subscribed!")
                }

                override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                    Log.w("MainTrackingMqtt", "Subscribed fail!")
                }
            })

        } catch (ex: MqttException) {
            System.err.println("Exception whilst subscribing")
            ex.printStackTrace()
        }

    }

    fun subscribeToTopic(qos: Int = 2) {
        try {
            mqttAndroidClient.subscribe(topic, qos, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken) {
                    Log.w("MainTrackingMqtt", "Subscribed!")
//                    publishData("DATA")
                }

                override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                    Log.w("MainTrackingMqtt", "Subscribed fail!")
                }
            })

        } catch (ex: MqttException) {
            System.err.println("Exception whilst subscribing")
            ex.printStackTrace()
        }
    }

    fun isConnected(): Boolean {
        return mqttAndroidClient.isConnected
    }

    fun publishData(data: String) {
        try {
            mqttAndroidClient?.publish(topic, MqttMessage().apply {
                this.payload = data.toByteArray()
                this.qos = 2
                this.isRetained = true
            })
        } catch (e: MqttPersistenceException) {
            e.printStackTrace();

        } catch (e: MqttException) {
            e.printStackTrace();
        }
    }

    fun disconnect() {
        try {
            mqttAndroidClient.disconnect(2)
        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }


    companion object {

        const val serverUri = "tcp://broker.hivemq.com:1883"

        const val username = "ildzqsen"
        const val password = "mF1PBsGjWXBt"
    }
}