package com.example.mqtt_test

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended
import org.eclipse.paho.client.mqttv3.MqttMessage
import java.util.*


class MainActivity : AppCompatActivity() {

    private lateinit var mqttHelper: MqttHelper
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var mRecyclerView: RecyclerView
    private val mAdapter = RecyclerViewAdapter()

    private val db = Firebase.firestore

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mRecyclerView = findViewById(R.id.recyclerView)
        mRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mRecyclerView.adapter = mAdapter

        db.collection("History")
            .addSnapshotListener { value, e ->
                if (e != null) {
                    Toast.makeText(this, "Error fetching data", Toast.LENGTH_LONG).show()
                    return@addSnapshotListener
                }

                val list = ArrayList<Data>()
                for (doc in value!!) {
                    val data = Data(doc.getString("Action") ?: "", doc.getDate("Time") ?: Date())
                    list.add(data)
                }
                list.sortByDescending { it.date }
                mAdapter.submitList(list)
                Handler().postDelayed({
                    mRecyclerView.smoothScrollToPosition(0)
                }, 500)
            }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(
                this,
                "SpeechRecognizer is not available in your device !",
                Toast.LENGTH_LONG
            ).show()
//            val appPackageName = "com.google.android.googlequicksearchbox"
//            try {
//                startActivity(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("market://details?id=$appPackageName")
//                    )
//                )
//            } catch (anfe: ActivityNotFoundException) {
//                startActivity(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName")
//                    )
//                )
//            }
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val speechRecognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        speechRecognizerIntent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())

        val fab = findViewById<FloatingActionButton>(R.id.publish)
        fab.setOnTouchListener { _, motionEvent ->
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                if (motionEvent.action == MotionEvent.ACTION_UP) {
                    speechRecognizer.stopListening()
                }
                if (motionEvent.action == MotionEvent.ACTION_DOWN) {
                    Toast.makeText(this@MainActivity, "Starting ....", Toast.LENGTH_LONG).show()
                    speechRecognizer.startListening(speechRecognizerIntent)
                }
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "SpeechRecognizer unavailable !",
                    Toast.LENGTH_LONG
                ).show()
            }
            false
        }

        mqttHelper =
            MqttHelper(context = this, "ENIT_STR", callback = object : MqttCallbackExtended {
                override fun connectComplete(b: Boolean, s: String) {
//                subscribeToDevice()
//                _userDevice.postValue(deviceId)
                }

                override fun connectionLost(throwable: Throwable?) {
//                _userDevice.postValue("")
                    throwable?.printStackTrace()
                }

                @Throws(Exception::class)
                override fun messageArrived(topic: String, mqttMessage: MqttMessage) {
//                Log.w("MainTrackingMQTTMSG", "Topic: $topic - MSG: $mqttMessage")
//                processMQTTData(mqttMessage.toString())
                }

                override fun deliveryComplete(iMqttDeliveryToken: IMqttDeliveryToken) {

                }
            })

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            checkPermission()
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(bundle: Bundle) {}
            override fun onBeginningOfSpeech() {
                Toast.makeText(this@MainActivity, "recording ....", Toast.LENGTH_LONG).show()
            }

            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(bytes: ByteArray) {}
            override fun onEndOfSpeech() {}
            override fun onError(i: Int) {}
            override fun onResults(bundle: Bundle) {
                val data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                Toast.makeText(this@MainActivity, "onResults - ${data?.get(0)}", Toast.LENGTH_LONG)
                    .show()
                if (mqttHelper.isConnected()) {
                    mqttHelper.publishData(data?.get(0) ?: "Empty data")
                }
            }

            override fun onPartialResults(bundle: Bundle) {}
            override fun onEvent(i: Int, bundle: Bundle) {}
        })

    }

    override fun onDestroy() {
        super.onDestroy()
        mqttHelper.disconnect()

        speechRecognizer.destroy();
    }


    private fun checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                RecordAudioRequestCode
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RecordAudioRequestCode && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) Toast.makeText(
                this,
                "Permission Granted",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    companion object {
        const val RecordAudioRequestCode = 1
    }
}

data class Data(val action: String, val date: Date)